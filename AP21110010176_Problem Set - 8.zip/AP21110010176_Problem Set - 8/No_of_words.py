def count_file_content(file_path):
    with open(file_path, 'r') as file:
        text = file.read()
        num_chars = len(text)
        num_numbers = sum(char.isdigit() for char in text)
        num_words = len(text.split())
    return num_chars, num_numbers, num_words

file_path = ''  
num_chars, num_numbers, num_words = count_file_content(file_path)

print(f"Number of characters: {num_chars}")
print(f"Number of numbers: {num_numbers}")
print(f"Number of words: {num_words}")
