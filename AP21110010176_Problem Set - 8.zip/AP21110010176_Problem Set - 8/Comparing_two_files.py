def compute_similarity(file_1, file_2):
    with open(file_1, 'r') as f:
        words_1 = f.read().lower().split()
    with open(file_2, 'r') as f:
        words_2 = f.read().lower().split()

    common_words = len(set(words_1) & set(words_2))
    total_words = len(set(words_1)) + len(set(words_2))

    return common_words / total_words


file_1 = 'C:/Users/Chetan Sai/Downloads/AI LAB/AP21110010176_Problem Set - 8/File_1.txt'
file_2 = 'C:/Users/Chetan Sai/Downloads/AI LAB/AP21110010176_Problem Set - 8/File_2.txt'
similarity_index = compute_similarity(file_1, file_2)
print(f'Similarity index: {similarity_index}')
