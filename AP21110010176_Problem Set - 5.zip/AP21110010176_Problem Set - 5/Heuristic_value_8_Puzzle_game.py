def move(state, direction):
    
    new_state = [list(row) for row in state]
    empty_row, empty_col = find_empty_tile(state)

    if direction == 'Up' and empty_row > 0:
        new_state[empty_row][empty_col], new_state[empty_row - 1][empty_col] = new_state[empty_row - 1][empty_col], new_state[empty_row][empty_col]
    elif direction == 'Down' and empty_row < 2:
        new_state[empty_row][empty_col], new_state[empty_row + 1][empty_col] = new_state[empty_row + 1][empty_col], new_state[empty_row][empty_col]
    elif direction == 'Left' and empty_col > 0:
        new_state[empty_row][empty_col], new_state[empty_row][empty_col - 1] = new_state[empty_row][empty_col - 1], new_state[empty_row][empty_col]
    elif direction == 'Right' and empty_col < 2:
        new_state[empty_row][empty_col], new_state[empty_row][empty_col + 1] = new_state[empty_row][empty_col + 1], new_state[empty_row][empty_col]

    return new_state if new_state != state else None
    
    
    
    
def find_empty_tile(state):
    
    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                return i, j
                
                
                
                
                
def calculate_heuristic(state, goal_state):
    
    heuristic = 0
    for i in range(3):
        for j in range(3):
            if state[i][j] != goal_state[i][j]:
                heuristic += 1
    return heuristic





def create(initial_state, level):
    
    goal_state = [[1, 2, 3], [4, 5, 6], [7, 8, 0]]
    queue = [(initial_state, 0)]

    while queue:
        current_state, current_level = queue.pop(0)

        if current_level > level:
            break

        
        heuristic_value = calculate_heuristic(current_state, goal_state)

        print(f"Level {current_level} (Heuristic Value: {heuristic_value}):\n")
        for row in current_state:
            print(" ".join(map(str, row)))
        print()

        next_level = current_level + 1
        for direction in ['Up', 'Down', 'Left', 'Right']:
            new_state = move(current_state, direction)
            if new_state is not None:
                queue.append((new_state, next_level))


initial_state = [[1, 2, 3], [4, 0, 5], [6, 7, 8]]
level = 4
create(initial_state, level)
