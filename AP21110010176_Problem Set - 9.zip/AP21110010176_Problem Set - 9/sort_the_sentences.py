with open("C:\\Users\\Chetan Sai\\Downloads\\AI LAB\\AP21110010176_Problem Set - 8\\AP21110010176_Problem Set - 9\\Sample.txt", 'r') as input_file:
    with open("C:\\Users\\Chetan Sai\\Downloads\\AI LAB\\AP21110010176_Problem Set - 8\\AP21110010176_Problem Set - 9\\Sample_1.txt", 'w') as output_file:
        for line in input_file:
            s1 = line.lower().split()

            # Sorting the words within the line
            s2 = sorted(s1)
            
            # Join the sorted words to form the sorted line
            sorted_line = ' '.join(s2)
            output_file.write(sorted_line + '\n')
