from collections import defaultdict

class Graph:
    def __init__(self, num_nodes):
        self.num_nodes = num_nodes
        self.adj_matrix = [[0 for _ in range(num_nodes)] for _ in range(num_nodes)]
        self.adj_list = defaultdict(list)

    def add_edge_matrix(self, u, v):
        self.adj_matrix[u][v] = 1
        self.adj_matrix[v][u] = 1

    def add_edge_list(self, u, v):
        self.adj_list[u].append(v)
        self.adj_list[v].append(u)

    def BFS(self, s):
        visited = [False] * (self.num_nodes)
        queue = []
        queue.append(s)
        visited[s] = True

        while queue:
            s = queue.pop(0)
            print(s, end=" ")

            for i in range(self.num_nodes):
                if self.adj_matrix[s][i] == 1 and visited[i] == False:
                    queue.append(i)
                    visited[i] = True

    def DFS(self, s):
        visited = [False] * (self.num_nodes)
        self.DFSUtil(s, visited)

    def DFSUtil(self, v, visited):
        visited[v] = True
        print(v, end=" ")

        for i in range(self.num_nodes):
            if self.adj_matrix[v][i] == 1 and visited[i] == False:
                self.DFSUtil(i, visited)

num_nodes = int(input("Enter the number of nodes: "))
num_edges = int(input("Enter the number of edges: "))

g = Graph(num_nodes)

print("Enter the edges:")
for _ in range(num_edges):
    u, v = map(int,input().split())
    g.add_edge_matrix(u,v)
    g.add_edge_list(u,v)

while True:
    print("\nB/b: BFS Traversal")
    print("D/d: DFS Traversal")
    print("T/t: Both BFS and DFS traversal")
    print("X/x: Exit")

    case = input("\nEnter your choice: ")

    if case.lower() == 'b':
        start_node = int(input("Enter the start node for BFS: "))
        print("BFS Traversal: ")
        g.BFS(start_node)
    elif case.lower() == 'd':
        start_node = int(input("Enter the start node for DFS: "))
        print("DFS Traversal: ")
        g.DFS(start_node)
    elif case.lower() == 't':
        start_node_bfs = int(input("Enter the start node for BFS: "))
        start_node_dfs = int(input("Enter the start node for DFS: "))
        print("BFS Traversal: ")
        g.BFS(start_node_bfs)
        print("\nDFS Traversal: ")
        g.DFS(start_node_dfs)
    elif case.lower() == 'x':
        break
