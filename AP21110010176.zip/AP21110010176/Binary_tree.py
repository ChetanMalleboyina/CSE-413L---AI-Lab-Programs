def isMirror(left, right):
    if left is None and right is None:
        return True
    
    if left is None or right is None:
        return False
    
    return (
        left[0] == right[0] and
        isMirror(left[1], right[2]) and
        isMirror(left[2], right[1])
    )

def isSymmetric(root):
    if root is None:
        return True

    return isMirror(root[1], root[2])

# Create the tree using nested lists
root = [1, [2, [3, None, None], [4, None, None]], [2, [4, None, None], [3, None, None]]]

result = isSymmetric(root)

if result:
    print("The binary tree is a mirror image of itself, i.e ",result)
else:
    print("The binary tree is not a mirror image of itself, i.e ",result)
