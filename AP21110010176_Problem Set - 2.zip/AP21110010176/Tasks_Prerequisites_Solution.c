#include <stdio.h>
#include <stdbool.h>

#define MAX_TASKS 1000
#define MAX_PREREQUISITES 10000

bool canFinish(int tasks, int prerequisites[][2], int n) {
    int graph[MAX_TASKS][MAX_TASKS] = {0};
    
    for (int i = 0; i < n; i++) {
        graph[prerequisites[i][1]][prerequisites[i][0]] = 1;
    }
    
    bool visited[MAX_TASKS] = {false};
    bool stack[MAX_TASKS] = {false};
    
    bool hasCycle(int node) {
        visited[node] = true;
        stack[node] = true;
        
        for (int neighbor = 0; neighbor < tasks; neighbor++) {
            if (!visited[neighbor] && graph[node][neighbor]) {
                if (hasCycle(neighbor)) {
                    return true;
                }
            } else if (stack[neighbor] && graph[node][neighbor]) {
                return true;
            }
        }
        
        stack[node] = false;
        return false;
    }
    
    for (int i = 0; i < tasks; i++) {
        if (!visited[i] && hasCycle(i)) {
            return false;
        }
    }
    
    return true;
}

int main() {
    int T;
    printf("Enter the no. of test cases to be checked: ");
    scanf("%d", &T);
    for (int t = 0; t < T; t++) {
        int tasks, n;
        printf("Enter the no. of tasks and prerequisites: ");
        scanf("%d %d", &tasks, &n);
        int prerequisites[MAX_PREREQUISITES][2];
        
        for (int i = 0; i < n; i++) {
            scanf("%d %d", &prerequisites[i][0], &prerequisites[i][1]);
        }
        
        bool result = canFinish(tasks, prerequisites, n);
        printf("%s\n", result ? "true" : "false"); // Print "true" if result is true, otherwise "false"
    }

    return 0;
}