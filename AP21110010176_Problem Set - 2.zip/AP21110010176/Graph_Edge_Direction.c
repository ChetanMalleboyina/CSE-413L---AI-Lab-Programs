#include <stdio.h>
#include <stdlib.h>

#define MAX_N 1000
#define MAX_M 10000

struct Edge {
    int u, v;
};

int solve(int N, int M, struct Edge* edges, int* directions) {
    int adj_list[MAX_N + 1][MAX_N + 1] = {0};
    int degree[MAX_N + 1] = {0};
    
    for (int i = 0; i < M; i++) {
        int u = edges[i].u;
        int v = edges[i].v;
        adj_list[u][v] = 1;
        adj_list[v][u] = 1;
        degree[u]++;
        degree[v]++;
    }

    for (int i = 0; i < M; i++) {
        int u = edges[i].u;
        int v = edges[i].v;
        if (degree[u] % 2 == 0) {
            directions[i] = 0;
            degree[v]--;
        } else if (degree[v] % 2 == 0) {
            directions[i] = 1;
            degree[u]--;
        }
    }

    int all_even = 1;
    for (int i = 1; i <= N; i++) {
        if (degree[i] % 2 != 0) {
            all_even = 0;
            break;
        }
    }

    return all_even;
}

int main() {
    int T;
    scanf("%d", &T);
    for (int t = 0; t < T; t++) {
        int N, M;
        scanf("%d %d", &N, &M);
        struct Edge edges[MAX_M];
        for (int i = 0; i < M; i++) {
            scanf("%d %d", &edges[i].u, &edges[i].v);
        }
        int directions[MAX_M];
        int result = solve(N, M, edges, directions);

        if (result) {
            for (int i = 0; i < M; i++) {
                printf("%d ", directions[i]);
            }
            printf("\n");
        } else {
            printf("-1\n");
        }
    }

    return 0;
}