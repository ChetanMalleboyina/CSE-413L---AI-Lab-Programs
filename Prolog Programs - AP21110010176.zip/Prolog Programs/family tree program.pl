% family tree program
male(john).
male(bob).
male(jim).
female(mary).
female(susan).
parent(john, jim).
parent(john, susan).
parent(mary, jim).
parent(mary, susan).
parent(bob, john).

% Rules
mother(M, P) :-
    parent(M, P),
    female(M).

father(F, P) :-
    parent(F, P),
    male(F).

sibling(X, Y) :-
    parent(P, X),
    parent(P, Y),
    X \= Y.

grandparent(G, P) :-
    parent(G, X),
    parent(X, P).

uncle_aunt(U, P) :-
    sibling(U, X),
    parent(X, P).

sister(S, P) :-
    sibling(S, P),
    female(S).

brother(B, P) :-
    sibling(B, P),
    male(B).
