% Substring
substring(S, L) :-
    append(_, L2, L), append(S, _, L2).

% String Position
string_position(S, L, P) :-
    append(A, _, L),
    append(_, [S], A),
    length(A, P).

% Palindrome
palindrome(L) :-
    reverse(L, L).
