% a.) Student percentage calculation:

student(john, 1, [[math, 100, 85], [english, 100, 90], [science, 100, 95], [history, 100, 88], [geography, 100, 92], [art, 100, 96]]).

percentage(Student, Percentage) :-
    student(Student, _, Marks),
    total_marks(Marks, Total, OutOf),
    Percentage is Total / OutOf * 100.

total_marks([], 0, 0).
total_marks([[_, Max, Obtained]|T], Total, OutOf) :-
    total_marks(T, TotalRest, OutOfRest),
    Total is Obtained + TotalRest,
    OutOf is Max + OutOfRest.


% b.) Employee salary calculation:

employee(john, software, engineer, 30, 50000, 10000).

salary(Employee, Gross) :-
    employee(Employee, _, _, _, Basic, HRA),
    DA is Basic * 0.15,
    Gross is Basic + HRA + DA.

