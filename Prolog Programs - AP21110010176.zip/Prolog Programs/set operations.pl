% Union
union([], L, L).
union([X|L1], L2, L3) :-
    member(X, L2), !,
    union(L1, L2, L3).
union([X|L1], L2, [X|L3]) :-
    union(L1, L2, L3).

% Intersection
intersection([], _, []).
intersection([X|L1], L2, [X|L3]) :-
    member(X, L2), !,
    intersection(L1, L2, L3).
intersection([_|L1], L2, L3) :-
    intersection(L1, L2, L3).

% Complement
complement([], _, []).
complement([X|L1], L2, L3) :-
    member(X, L2), !,
    complement(L1, L2, L3).
complement([X|L1], L2, [X|L3]) :-
    complement(L1, L2, L3).
