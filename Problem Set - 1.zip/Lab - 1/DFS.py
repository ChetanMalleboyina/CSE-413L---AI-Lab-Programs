visited = set() 

def dfs(visited, graph, node):  
    if node not in visited:
        print (node, end= " ")
        visited.add(node)
        for neighbour in graph[node]:
            dfs(visited, graph, neighbour)

graph = {'A': ['B', 'C'],'B': ['D', 'E'],'C': ['F', 'G'],'D': [],'E': ['H', 'I'],'F': [],'G': [],'G': [],'H': [],'I': ['J', 'K'],'J': [],'K': ['L'],'L': []}

print("This is the Depth-First Search (DFS) : ")
dfs(visited, graph, 'A')