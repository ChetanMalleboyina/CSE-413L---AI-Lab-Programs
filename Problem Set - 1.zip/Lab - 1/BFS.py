def bfs(graph, starting_of_the_node):
    visited_nodes = []
    queue = [starting_of_the_node]

    while queue:
        node = queue.pop(0)
        if node not in visited_nodes:
            visited_nodes.append(node)
            print(node, end=" ")

            for neighbor in graph[node]:
                if neighbor not in visited_nodes:
                    queue.append(neighbor)

graph = {'A': ['B', 'C'],'B': ['D', 'E'],'C': ['F', 'G'],'D': [],'E': ['H', 'I'],'F': [],'G': [],'G': [],'H': [],'I': ['J', 'K'],'J': [],'K': ['L'],'L': []}

print("This is the Breadth-First Search (BFS) : ")
bfs(graph, 'A')
