class Graph:
    def __init__(self, n):
        self.graph = {}
        self.N = n
        for i in range(n):
            self.graph[i] = []

    def addEdge(self, m, n):
        self.graph[m].append(n)

    def topologicalSortUtil(self, n, visited, stack):
        visited[n] = True
        for element in self.graph[n]:
            if not visited[element]:
                self.topologicalSortUtil(element, visited, stack)
        stack.insert(0, n)

    def topologicalSort(self):
        visited = [False] * self.N
        stack = []

        for element in range(self.N):
            if not visited[element]:
                self.topologicalSortUtil(element, visited, stack)
        
        
        return stack
    
    
graph = Graph(5)
graph.addEdge(0, 1)
graph.addEdge(0, 3)
graph.addEdge(1, 2)
graph.addEdge(2, 3)
graph.addEdge(2, 4)
graph.addEdge(3, 4)

print("This is Topological Sort Of the graph : ")
print(graph.topologicalSort())